export const GENERATE_NEW_PIN = "generate_new_pin";
export const SAVE_PIN = "save_pin";
export const UPDATE_PIN_NAME = "update_pin_name";
export const DELETE_PIN = "delete_pin";
export const CHANGE_PAGE = "change_page";
export const RESET_GENERATOR = "reset_generator";
